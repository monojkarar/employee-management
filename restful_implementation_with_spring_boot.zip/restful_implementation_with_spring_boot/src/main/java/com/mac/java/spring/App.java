package com.mac.java.spring;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");

        List<String> data = Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
        List<String> result = data.stream().filter(d -> (d.equalsIgnoreCase("a") || d.equalsIgnoreCase("e") || d.equalsIgnoreCase("i") || d.equalsIgnoreCase("o") || d.equalsIgnoreCase("u"))).collect(Collectors.toList());
        System.out.print(result);
    }
}
