package com.mac.java.spring.exception;

import java.io.Serializable;
import java.util.Date;

public class ExceptionResponse implements Serializable {

	private static final long serialVersionUID = -3714640802117491515L;

	private Date date;
	private String message;
	private String description;

	public ExceptionResponse(Date date, String message, String description) {
		this.date = date;
		this.message = message;
		this.description = description;
	}

	public Date getDate() {
		return date;
	}

	public String getMessage() {
		return message;
	}

	public String getDescription() {
		return description;
	}

}
