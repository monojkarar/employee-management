package com.mac.java.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mac.java.spring.exception.ResourceNotFoundException;
import com.mac.java.spring.number.converters.NumericConverter;
import com.mac.java.spring.number.operations.MathOperations;

@RestController
public class MathController {
	@Autowired
	private NumericConverter numericConverter;

	@Autowired
	private MathOperations mathOperations;

	@RequestMapping(value = "/sum/{numberOne}/{numberTwo}", method = RequestMethod.GET)
	public Double sum(@PathVariable("numberOne") String numberOne, @PathVariable("numberTwo") String numberTwo)
			throws Exception {
		if (!numericConverter.isNumber(numberOne) || !numericConverter.isNumber(numberTwo)) {
			throw new ResourceNotFoundException("Please pass a numeric value!");
		}
		Double result = mathOperations.sum(numericConverter.convertIntoDouble(numberOne),
				numericConverter.convertIntoDouble(numberTwo));
		return result;
	}

	@RequestMapping(value = "/subtract/{numberOne}/{numberTwo}", method = RequestMethod.GET)
	public Double subtract(@PathVariable("numberOne") String numberOne, @PathVariable("numberTwo") String numberTwo)
			throws Exception {
		if (!numericConverter.isNumber(numberOne) || !numericConverter.isNumber(numberTwo)) {
			throw new ResourceNotFoundException("Please pass a numeric value!");
		}
		Double result = mathOperations.subtract(numericConverter.convertIntoDouble(numberOne),
				numericConverter.convertIntoDouble(numberTwo));
		return result;
	}

	@RequestMapping(value = "/multiply/{numberOne}/{numberTwo}", method = RequestMethod.GET)
	public Double multiply(@PathVariable("numberOne") String numberOne, @PathVariable("numberTwo") String numberTwo)
			throws Exception {
		if (!numericConverter.isNumber(numberOne) || !numericConverter.isNumber(numberTwo)) {
			throw new ResourceNotFoundException("Please pass a numeric value!");
		}
		Double result = mathOperations.multiply(numericConverter.convertIntoDouble(numberOne),
				numericConverter.convertIntoDouble(numberTwo));
		return result;
	}

	@RequestMapping(value = "/divide/{numberOne}/{numberTwo}", method = RequestMethod.GET)
	public Double divide(@PathVariable("numberOne") String numberOne, @PathVariable("numberTwo") String numberTwo)
			throws Exception {
		if (!numericConverter.isNumber(numberOne) || !numericConverter.isNumber(numberTwo)) {
			throw new ResourceNotFoundException("Please pass a numeric value!");
		}
		Double result = numericConverter.convertIntoDouble(numberOne) / numericConverter.convertIntoDouble(numberTwo);
		return result;
	}

	@RequestMapping(value = "/average/{numberOne}/{numberTwo}", method = RequestMethod.GET)
	public Double average(@PathVariable("numberOne") String numberOne, @PathVariable("numberTwo") String numberTwo)
			throws Exception {
		if (!numericConverter.isNumber(numberOne) || !numericConverter.isNumber(numberTwo)) {
			throw new ResourceNotFoundException("Please pass a numeric value!");
		}
		Double result = mathOperations.divide(numericConverter.convertIntoDouble(numberOne),
				numericConverter.convertIntoDouble(numberTwo));
		return result;
	}

	@RequestMapping(value = "/square/{number}", method = RequestMethod.GET)
	public Double square(@PathVariable("number") String number) throws Exception {
		if (!numericConverter.isNumber(number)) {
			throw new ResourceNotFoundException("Please pass a numeric value!");
		}

		Double result = mathOperations.square(numericConverter.convertIntoDouble(number));
		return result;
	}
}
