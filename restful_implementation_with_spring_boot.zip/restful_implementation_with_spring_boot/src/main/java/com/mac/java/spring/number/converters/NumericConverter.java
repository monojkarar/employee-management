package com.mac.java.spring.number.converters;

import org.springframework.stereotype.Component;

@Component
public class NumericConverter {

	public Double convertIntoDouble(String number) {
		if (number == null)
			return 0D;
		number = number.replaceAll(",", ".");
		if (isNumber(number))
			return Double.parseDouble(number);
		return 0D;
	}

	public boolean isNumber(String number) {
		if (number == null)
			return false;
		number = number.replaceAll(",", ".");
		return number.matches("[-+]?[0-9]*\\.?[0-9]+");
	}
	
}
