package com.mac.java.spring.services;

import com.mac.java.spring.exception.ResourceNotFoundException;
import com.mac.java.spring.model.Person;
import com.mac.java.spring.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PersonService {

    PersonRepository personRepository;

    @Autowired
    public void setPersonRepository(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public Person findById(Long id) {
        return personRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No records found for the ID."));
    }

    public List<Person> findAll() {
        return personRepository.findAll();
    }

    public Person create(Person person) {
        personRepository.insert(person);
        int lastId = personRepository.getLastId();
        return personRepository.findById(lastId).orElse(new Person());
    }

    public Person update(Person person) {
        Person presentPerson = personRepository.findById(person.getId()).orElseThrow(() -> new ResourceNotFoundException("No records found for the ID."));
        presentPerson.setFirstName(person.getFirstName());
        presentPerson.setLastName(person.getLastName());
        presentPerson.setGender(person.getGender());
        presentPerson.setAddress(person.getAddress());
        personRepository.update(presentPerson);
        return personRepository.findById(person.getId()).orElse(new Person());
    }
    public void delete(Long id) {
        personRepository.deleteById(id);
    }
}
