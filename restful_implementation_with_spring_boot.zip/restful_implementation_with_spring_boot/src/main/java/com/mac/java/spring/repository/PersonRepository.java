package com.mac.java.spring.repository;

import com.mac.java.spring.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class PersonRepository {

    private final RowMapper<Person> personRowMapper = (rs, rowNum) -> {
        Person person = new Person();
        person.setId(rs.getLong("id"));
        person.setFirstName(rs.getString("first_name"));
        person.setLastName(rs.getString("last_name"));
        person.setGender(rs.getString("gender"));
        person.setAddress(rs.getString("address"));
        return person;
    };
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Person> findAll() {
        return jdbcTemplate.query("select id, first_name, last_name, gender, address from person where status = 1", personRowMapper);
    }

    public Optional<Person> findById(long id) {
        return Optional.of(jdbcTemplate.queryForObject("select id, first_name, last_name, gender, address from person where id=? and status = 1", new Object[]{id}, new BeanPropertyRowMapper<>(Person.class)));
    }

    public int insert(Person person) {
        return jdbcTemplate.update("insert into person (first_name, last_name, gender, address) " +
                "values(?, ?, ?, ?)", person.getFirstName(), person.getLastName(), person.getGender(), person.getAddress());
    }

    public int update(Person person) {
        return jdbcTemplate.update("update person set first_name = ?, last_name = ?, gender = ?, address= ? where id = ?",
                person.getFirstName(), person.getLastName(), person.getGender(), person.getAddress(), person.getId());
    }

    public int deleteById(long id) {
        return jdbcTemplate.update("update person set status = 0 where id=?", id);
    }

    public int getLastId() {
        return jdbcTemplate.queryForObject("Select id as last_id from Person order by ID desc LIMIT 1", Integer.class);
    }

    /*
    class PersonRowMapper implements RowMapper<Person> {
        @Override
        public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
            Person person = new Person();
            person.setId(rs.getLong("id"));
            person.setFirstName(rs.getString("first_name"));
            person.setLastName(rs.getString("last_name"));
            person.setGender(rs.getString("gender"));
            person.setAddress(rs.getString("address"));
            return person;
        }
    }
    */
}
