package com.mac.java.spring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class StartUp {

    private final static Logger LOGGER = LoggerFactory.getLogger(StartUp.class);
    public static void main(String... args) {
        SpringApplication.run(StartUp.class, args);

//        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
//        applicationContext.getBean("beanA");
//        BeanB beanB = (BeanB) applicationContext.getBean("beanB");
//        System.out.println(beanB);
//        Bean1 bean1 = (Bean1) applicationContext.getBean("bean1");
//        LOGGER.debug(bean1 + " -> " +bean1.getBeans());
//
//        Bean1 bean2 = (Bean1) applicationContext.getBean("bean1");
//        LOGGER.debug(bean2 + " -> " +bean2.getBeans());
    }
}
